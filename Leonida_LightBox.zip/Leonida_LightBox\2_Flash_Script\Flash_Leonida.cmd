@echo off
setlocal
cd /d "%~dp0"
title Leonida light box - upload firmware to ESP32
echo.
echo  ================================================
echo   LEONIDA LIGHT BOX - upload firmware to ESP32
echo  ================================================
echo.

rem --- 1. Check that Python is installed ----------------------------------
python --version >nul 2>nul
if errorlevel 1 (
  echo  [ERROR] Python is not installed.
  echo          Download Python from https://www.python.org/downloads/
  echo          and tick "Add python.exe to PATH" during installation.
  goto end
)

rem --- 2. Check / install esptool -----------------------------------------
python -m esptool version >nul 2>nul
if errorlevel 1 (
  echo  Installing esptool ^(first time only^) ...
  python -m pip install --user "esptool<5"
  python -m esptool version >nul 2>nul
  if errorlevel 1 (
    echo  [ERROR] esptool could not be installed. Check your internet connection.
    goto end
  )
)

rem --- 3. COM port --------------------------------------------------------
set "PORT=%~1"
if "%PORT%"=="" (
  echo  Connected COM ports:
  powershell -NoProfile -Command "Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match '\(COM\d+\)' } | ForEach-Object { '    ' + $_.Name }"
  echo.
  set /p "PORT= Enter the COM port of the ESP32 (e.g. COM7): "
)

rem --- 4. Choose variant --------------------------------------------------
set "CHOICE=%~2"
if "%CHOICE%"=="" (
  echo.
  echo  How is the light box powered?
  echo    1 = from USB / PC           ^(max 500 mA, dimmer^)
  echo    2 = 5V 4A power supply      ^(max 3000 mA, bright^)
  set /p "CHOICE= Choice (1 or 2): "
)
if "%CHOICE%"=="2" (
  set "BIN=..\1_Firmware\Leonida_5V-power-supply_3000mA.bin"
) else (
  set "BIN=..\1_Firmware\Leonida_USB-power_500mA.bin"
)
if not exist "%BIN%" (
  echo  [ERROR] Cannot find %BIN%
  goto end
)

echo.
echo  Port: %PORT%
echo  File: %BIN%
echo.
echo  Erasing the ESP32 completely ...
python -m esptool --chip esp32 --port %PORT% --baud 460800 erase_flash
if errorlevel 1 goto failed

echo.
echo  Writing firmware ...
python -m esptool --chip esp32 --port %PORT% --baud 460800 write_flash 0x0 "%BIN%"
if errorlevel 1 goto failed

echo.
echo  ================================================
echo   DONE - the ESP32 restarts and runs the start-up test
echo  ================================================
goto end

:failed
echo.
echo  [ERROR] The upload failed. Try this:
echo    - Check that you entered the correct COM port
echo    - Close other programs using the port (Arduino IDE, serial monitor)
echo    - Unplug the USB cable and plug it back in
echo    - Hold the BOOT button on the ESP32 while "Connecting..." is shown
echo    - Try another USB cable (it must support data, not just charging)

:end
echo.
if "%~3"=="" pause
endlocal
