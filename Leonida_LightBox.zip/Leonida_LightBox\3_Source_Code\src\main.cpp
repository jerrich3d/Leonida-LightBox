// Leonida light box - sunrise/sunset behind the city line
// 11 rows x 12 WS2812B, serpentine wiring, chain starts bottom right.
// Rows 1-6 (top) = city line, rows 7-11 = behind the city name.

#include <Arduino.h>
#include <FastLED.h>

// ---------------- Hardware ----------------
#define DATA_PIN     13          // yellow wire -> D13
#define COLS         12
#define ROWS         11
#define CITY_ROWS    6
#define NUM_LEDS     (COLS * ROWS)

// Current budget for the whole box incl. the ESP32 (mA).
// PC/USB power: 500 (what a standard USB port guarantees). With a separate 5V
// power supply: about 75 % of the supply rating, e.g. 3000 for a 4A supply.
#ifndef MAX_MA
#define MAX_MA       500         // can be set from platformio.ini (build_flags)
#endif

// ---------------- Timing (seconds) ----------------
const float RISE_PER_ROW = 20.0f;   // sunrise, per row
const float FULL_TIME    = 180.0f;  // full light
const float DIM_TIME     = 60.0f;   // dimming of the whole city
const float DIM_TO       = 0.30f;   // city dims down to 30 %
const float OFF_PER_ROW  = 10.0f;   // switch-off per row (from the top)
const float DARK_TIME    = 8.0f;    // dark pause before the loop restarts
const float NAME_LEVEL   = 1.0f;    // city name (rows 7-11): constant brightness, 0.0-1.0

const float T_RISE = RISE_PER_ROW * CITY_ROWS;
const float T_FULL = T_RISE + FULL_TIME;
const float T_DIM  = T_FULL + DIM_TIME;
const float T_OFF  = T_DIM + OFF_PER_ROW * CITY_ROWS;
const float T_LOOP = T_OFF + DARK_TIME;

CRGB leds[NUM_LEDS];

// Colours from the sign: pink -> purple -> cyan (left to right)
struct RGBf { float r, g, b; };
const RGBf STOPS[3] = { {255, 70, 170}, {200, 110, 255}, {90, 225, 255} };
const RGBf SUN      = {255, 140, 60};

static inline float clamp01(float x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }
static inline float smooth(float x) { x = clamp01(x); return x * x * (3 - 2 * x); }
static inline RGBf mix(RGBf a, RGBf b, float f) {
  return { a.r + (b.r - a.r) * f, a.g + (b.g - a.g) * f, a.b + (b.b - a.b) * f };
}
static RGBf gradient(float x) {
  x = clamp01(x);
  float s = x * 2.0f;
  int i = s >= 1.0f ? 1 : 0;
  return mix(STOPS[i], STOPS[i + 1], s - i);
}

// Logical (row 0 = top, column 0 = left) -> physical index in the chain.
// The chain starts bottom right and runs right->left on the bottom row.
static int ledIndex(int row, int col) {
  int p = (ROWS - 1) - row;                 // physical row, 0 = bottom
  return (p % 2 == 0) ? p * COLS + (COLS - 1 - col) : p * COLS + col;
}

// Gamma, so the dimming looks even to the eye
static inline float gammaB(float b) { return powf(clamp01(b), 2.2f); }

static void setPixel(int row, int col, RGBf c, float b) {
  float g = gammaB(b);
  leds[ledIndex(row, col)] = CRGB((uint8_t)(c.r * g + 0.5f),
                                  (uint8_t)(c.g * g + 0.5f),
                                  (uint8_t)(c.b * g + 0.5f));
}

static float cityLevel(int row, float t) {
  int order = (CITY_ROWS - 1) - row;         // lowest city row starts first
  if (t < T_RISE) return smooth((t - order * RISE_PER_ROW) / RISE_PER_ROW);
  if (t < T_FULL) return 1.0f;
  if (t < T_DIM)  return 1.0f - (1.0f - DIM_TO) * smooth((t - T_FULL) / DIM_TIME);
  if (t < T_OFF)  return DIM_TO * (1.0f - smooth((t - T_DIM - row * OFF_PER_ROW) / OFF_PER_ROW));
  return 0.0f;
}

// The city name is not part of the sunrise/sunset - it stays at the same level.
static float nameLevel(float) { return NAME_LEVEL; }

static void renderFrame(float t) {
  for (int r = 0; r < CITY_ROWS; r++) {
    float b = cityLevel(r, t);
    for (int c = 0; c < COLS; c++) {
      RGBf col = gradient(c / float(COLS - 1));
      if (t < T_RISE) col = mix(SUN, col, smooth(b));   // warm sunrise tint
      setPixel(r, c, col, b);
    }
  }
  float L = nameLevel(t);
  for (int r = CITY_ROWS; r < ROWS; r++)
    for (int c = 0; c < COLS; c++)
      setPixel(r, c, gradient(c / float(COLS - 1) + (r - CITY_ROWS) * 0.04f), L);
}

// Short start-up test: each row lights up from the top, then R/G/B.
static void startupTest() {
  const CRGB rowCol[2] = { CRGB(60, 0, 0), CRGB(0, 0, 60) };   // city = red, name = blue
  for (int r = 0; r < ROWS; r++) {
    FastLED.clear();
    for (int c = 0; c < COLS; c++) leds[ledIndex(r, c)] = rowCol[r >= CITY_ROWS];
    leds[ledIndex(r, 0)] = CRGB(60, 60, 60);   // left LED white = shows orientation
    FastLED.show();
    delay(350);
  }
  const CRGB rgb[3] = { CRGB(50, 0, 0), CRGB(0, 50, 0), CRGB(0, 0, 50) };
  for (int i = 0; i < 3; i++) { fill_solid(leds, NUM_LEDS, rgb[i]); FastLED.show(); delay(700); }
  FastLED.clear(true);
  delay(300);
}

// Fixed brightness so the brightest frame of the whole cycle (full light) stays
// within MAX_MA. A fixed scale keeps the dimming proportional; FastLED's dynamic
// power limiter would instead turn brightness back UP as the city dims and
// cancel out the sunset.
static uint8_t fixedBrightness() {
  const uint32_t IDLE_MA = 100;                     // ESP32 + LED chips idle
  renderFrame(T_RISE + 1.0f);                       // full-light frame
  uint32_t mw = calculate_unscaled_power_mW(leds, NUM_LEDS);
  FastLED.clear();
  uint32_t budgetMw = (MAX_MA > IDLE_MA ? MAX_MA - IDLE_MA : 50) * 5;
  float scale = mw > budgetMw ? (float)budgetMw / mw : 1.0f;
  uint8_t b = (uint8_t)constrain((int)(scale * 255.0f), 1, 255);
  Serial.printf("Full light needs ~%lu mA unscaled -> fixed brightness %u/255 (~%lu mA)\n",
                (unsigned long)(mw / 5), b, (unsigned long)(mw / 5 * b / 255 + IDLE_MA));
  return b;
}

void setup() {
  Serial.begin(115200);
  delay(200);
  FastLED.addLeds<WS2812B, DATA_PIN, GRB>(leds, NUM_LEDS);
  FastLED.setDither(BINARY_DITHER);                 // smoother low-level dimming
  FastLED.clear(true);
  Serial.println("\nLeonida light box starting");
  Serial.printf("Current limit: %d mA\n", MAX_MA);
  uint8_t runBrightness = fixedBrightness();
  Serial.printf("Cycle: %.0f s  (sunrise %.0f, full %.0f, dimming %.0f, switch-off %.0f, dark %.0f)\n",
                T_LOOP, T_RISE, FULL_TIME, DIM_TIME, T_OFF - T_DIM, DARK_TIME);
  startupTest();                                    // runs at full scale (test colours are dim)
  FastLED.setBrightness(runBrightness);
  Serial.println("Start-up test done - animation running");
}

void loop() {
  static uint32_t start = millis();
  static int lastPhase = -1;
  float t = fmodf((millis() - start) / 1000.0f, T_LOOP);

  int phase = t < T_RISE ? 0 : t < T_FULL ? 1 : t < T_DIM ? 2 : t < T_OFF ? 3 : 4;
  renderFrame(t);

  static uint32_t lastReport = 0;
  bool newPhase = phase != lastPhase;
  if (newPhase || millis() - lastReport >= 30000) {
    static const char* names[] = { "Sunrise", "Full light", "Dimming", "Switching off from the top", "Dark" };
    uint32_t ma = calculate_unscaled_power_mW(leds, NUM_LEDS) / 5 * FastLED.getBrightness() / 255;
    Serial.printf("[%7lu ms] %-27s LED current ~%lu mA\n", (unsigned long)millis(),
                  newPhase ? names[phase] : "", (unsigned long)ma);
    lastPhase = phase;
    lastReport = millis();
  }

  FastLED.show();
  delay(16);   // approx. 60 fps
}
